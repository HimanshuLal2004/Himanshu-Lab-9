﻿using MySqlConnector;
using System;
using System.Collections.Generic;

namespace _1_Make_Connection_To_MariaDB
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                MySqlConnectionStringBuilder builder =
                  new MySqlConnectionStringBuilder
                  {
                      Server = "localhost",
                      UserID = "root",
                      Password = "OOP2@",
                      Database = "demo1",
                  };

                MySqlConnection connection =
                  new MySqlConnection(builder.ConnectionString);

                connection.Open();

                string studentSql = "SELECT * FROM student";

                MySqlCommand studentCommand = new MySqlCommand(studentSql, connection);

                MySqlDataReader studentReader = studentCommand.ExecuteReader();

                
                List<Student> students = new List<Student>();

                while (studentReader.Read())
                {
                    int id = studentReader.GetInt32(0);
                    string name = studentReader.GetString(1);
                    double gpa = studentReader.GetDouble(2);
                    string program = studentReader.GetString(3);
                    Student student = new Student(id, name, gpa, program);

                    
                    string courseSql = $"SELECT * FROM courses WHERE student_id = {id}";
                    using (MySqlConnection courseConnection = new MySqlConnection(builder.ConnectionString))
                    {
                        courseConnection.Open();
                        MySqlCommand courseCommand = new MySqlCommand(courseSql, courseConnection);
                        using (MySqlDataReader courseReader = courseCommand.ExecuteReader())
                        {
                            while (courseReader.Read())
                            {
                                
                                int courseId = courseReader.GetInt32(0);
                                string courseName = courseReader.GetString(1);
                                Course course = new Course(courseId, courseName);
                                student.Courses.Add(course);
                            }
                        }
                    }

                    
                    students.Add(student);
                }


                studentReader.Close();
                connection.Close();

                
                foreach (Student student in students)
                {
                    Console.WriteLine($"Student ID: {student.Id}, Name: {student.Name}, GPA: {student.Gpa}, Program: {student.Program}");
                    Console.WriteLine("Courses:");
                    foreach (Course course in student.Courses)
                    {
                        Console.WriteLine($" - {course.CourseName}");
                    }
                }

                Console.WriteLine("Database connection is closed.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
    }
}
