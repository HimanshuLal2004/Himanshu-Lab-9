﻿public class Student
{
    // Properties for Student entity
    public int Id { get; set; }
    public string Name { get; set; }
    public double Gpa { get; set; }
    public string Program {  get; set; }

    // List to hold courses for this student
    public List<Course> Courses { get; set; }

    // Constructor to initialize the list
    public Student(int id, string name, double gpa, string program)
    {
        Id = id;
        Name = name;
        Gpa = gpa;
        Program = program;
        Courses = new List<Course>();
    }
}