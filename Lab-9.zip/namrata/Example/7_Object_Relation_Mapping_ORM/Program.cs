﻿using MySqlConnector;
using System;

namespace _1_Make_Connection_To_MariaDB
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                MySqlConnectionStringBuilder builder =
                  new MySqlConnectionStringBuilder
                  {
                      Server = "localhost",
                      UserID = "root",
                      Password = "OOP2@",
                      Database = "demo1",
                  };

                MySqlConnection connection =
                  new MySqlConnection(builder.ConnectionString);

                connection.Open();


                string sql = "select * from student";

                MySqlCommand command = new MySqlCommand(sql, connection);

                MySqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    int id = reader.GetInt32(0);
                    string name = reader.GetString(1);
                    double gpa = reader.GetDouble(2);
                    string program = reader.GetString(3);
                    Student student = new Student(id, name, gpa,program);
                }

                connection.Close();

                Console.WriteLine("Database connection is closed.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
    }
}
