﻿using MySqlConnector;
using System;

namespace _1_Make_Connection_To_MariaDB
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                MySqlConnectionStringBuilder builder =
                  new MySqlConnectionStringBuilder
                  {
                      Server = "localhost",
                      UserID = "root",
                      Password = "OOP2@",
                      Database = "demo1",
                  };

                MySqlConnection connection =
                  new MySqlConnection(builder.ConnectionString);

                connection.Open();

                
                string insertSql = "INSERT INTO student (id, name, gpa, program) VALUES " +
                                   "(9, 'Alice', 3.75, 'Computer Science'), " +
                                   "(10, 'Bob', 3.80, 'Mathematics'), " +
                                   "(11, 'Charlie', 3.90, 'Physics')";


                MySqlCommand insertCommand = new MySqlCommand(insertSql, connection);


                int rowsAffected = insertCommand.ExecuteNonQuery();

                Console.WriteLine($"Number of rows inserted: {rowsAffected}");

                connection.Close();

                Console.WriteLine("Database connection is closed.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }
    }
}
