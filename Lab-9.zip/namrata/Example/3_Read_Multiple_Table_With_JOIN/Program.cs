﻿using MySqlConnector;
using System;

namespace _1_Make_Connection_To_MariaDB
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MySqlConnectionStringBuilder builder =
              new MySqlConnectionStringBuilder
              {
                  Server = "localhost",
                  UserID = "root",
                  Password = "OOP2@",
                  Database = "demo1",
              };

            MySqlConnection connection =
              new MySqlConnection(builder.ConnectionString);

            connection.Open();

            
            string sql = "SELECT * FROM student AS s INNER JOIN program AS p ON s.program = p.name";

            
            MySqlCommand command = new MySqlCommand(sql, connection);

            
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                
                while (reader.Read())
                {
                    
                    string name = reader.GetString("name");
                    Console.WriteLine(name);
                }
            }


            

            
            sql = "SELECT gpa FROM student WHERE id = 1";


            MySqlCommand gpaCommand = new MySqlCommand(sql, connection);

            double gpa = (double)gpaCommand.ExecuteScalar();

            Console.WriteLine($"The output of ExecuteScalar is the GPA {gpa}");


            connection.Close();

            Console.WriteLine("Database connection is closed.");
        }
    }
}
