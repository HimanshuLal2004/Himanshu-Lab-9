﻿using MySqlConnector;
using System;

namespace _1_Make_Connection_To_MariaDB
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                MySqlConnectionStringBuilder builder =
                  new MySqlConnectionStringBuilder
                  {
                      Server = "localhost",
                      UserID = "root",
                      Password = "OOP2@",
                      Database = "demo1",
                  };

                MySqlConnection connection =
                  new MySqlConnection(builder.ConnectionString);

                connection.Open();

                string sql = "UPDATE students SET gpa = 3.5 WHERE id = 9";

                
                MySqlTransaction transaction = connection.BeginTransaction();

                
                MySqlCommand command = new MySqlCommand(sql, connection, transaction);

                try
                {
                    
                    int affected = command.ExecuteNonQuery();  

                    
                    transaction.Commit(); 

                    Console.WriteLine($"Number of affected and commited rows is: {affected} row/s");
                }
                catch (MySqlException ex)
                {
                    
                    transaction.Rollback(); 

                    Console.WriteLine($"There is an EXCEPTION: {ex.ToString()}");
                }

                connection.Close();

                Console.WriteLine("Database connection is closed.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
    }
}
